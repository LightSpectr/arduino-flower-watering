** BH1750FVI driver **


This library aims to provide an easy use of the BH1750FVI Lightsensor.



License: MIT License

Copyright (c) 2017 PeterEmbedded
